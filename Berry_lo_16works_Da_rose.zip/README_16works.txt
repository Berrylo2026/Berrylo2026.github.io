Berry lo 16作品版（商品名一覧修正版）

このZIPの index.html では、掲載している16作品カードと下部の作品名一覧の順番・名称を一致させています。
「Halloween」「Mountain Sunrise」の誤記は作品名一覧から削除しました。
ただし、13〜16番の4作品は画像ファイル未収録のため「IMAGE PENDING」です。
旧サイトの画像・音楽等のファイルはGitHubリポジトリから削除しないでください。
ZIPを解凍して index.html と sleeping-puppy.webp をGitHubへアップロードしてください。
公開前に選定した16作品と名称・画像の最終照合が必要です。

16番の商品名は正式名称「Da rose」に修正しました。
